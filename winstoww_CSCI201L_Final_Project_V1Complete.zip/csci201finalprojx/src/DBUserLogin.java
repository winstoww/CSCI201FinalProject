import java.sql.*;
import java.util.ArrayList;
 
public class DBUserLogin {
 
    public static Profile tryLogin(String email, String password) throws SQLException, ClassNotFoundException {
        String dbURL = "jdbc:mysql://localhost/UserDatabase"; 
        String dbUser = "root";
        String dbPassword = "root"; //"password"-> your saved password
	Connection connection = null;
 	PreparedStatement statement = null;
	ResultSet result = null;
	    
	Class.forName("com.mysql.cj.jdbc.Driver");
        connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);
        String sql = "SELECT * FROM Profile WHERE email = ? and password = ?";
        statement = connection.prepareStatement(sql);
        statement.setString(1, email);
        statement.setString(2, password);
        result = statement.executeQuery();
 
        Profile user = null;
 
        if (result.next()) {
	    Location location = new Location(result.getDouble("latitude"), result.getDouble("longitude"));

	    
		
            user = new Profile(result.getInt("profileID"), result.getString("name"), result.getString("password"), result.getString("email"), location, null, null, null, true); 
            
	    
	  
	}
 
        try {
    	    if (result != null) {
    		result.close();
    	    }
    	    if (statement != null) {
    		statement.close();
    	    }
	    if (connection != null) {
    		connection.close();
    	    }
    	} catch (SQLException sqle) {
    	    System.out.println(sqle.getMessage());
    	}
 
        return user; //if user returns null then couldn't find in database -> incorrect email/password
    }
}
