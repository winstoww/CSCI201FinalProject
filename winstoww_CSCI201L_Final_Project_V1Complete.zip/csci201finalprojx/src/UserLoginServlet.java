import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import csci201finalprojx.GhettoProfile;
 
@WebServlet("/UserLoginServlet")
public class UserLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
 
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String destPage = "login.jsp";
       
        System.out.println(email + password);
        if (email == null || password == null || email.length() == 0 || password.length() == 0) {
            request.setAttribute("login_message", "Empty email/password");
        }
        else {
            try {
                Profile user = DBUserLogin.tryLogin(email, password);

                if (user == null) {
                    request.setAttribute("login_message", "Invalid email/password");
                } else { 
                    Database db = new Database();
                    user = db.getProfileByEmail(email);
                    System.out.println(user);
                	ArrayList<Profile> matches = user.matchmake(db.getAllProfiles()); 
                    //ArrayList<Profile> matches = db.getAllProfiles();
                	HttpSession session = request.getSession(); //HttpSession is used to store the user's information until logged out
                    session.setAttribute("user", new GhettoProfile(user.getName(), user.getEmail(), user.getID(), "Bass", "Rock")); //***** TODO: use later when you need to access user information -> Profile user = session.getAttribute("user");
                    session.setAttribute("prof1", new GhettoProfile(matches.get(0).getName(), matches.get(0).getEmail(), matches.get(0).getID(), "Violin" , "Rock"));
                    session.setAttribute("prof2", new GhettoProfile(matches.get(1).getName(), matches.get(1).getEmail(), matches.get(1).getID(), "Saxophone" , "Blues"));
                    session.setAttribute("prof3", new GhettoProfile(matches.get(2).getName(), matches.get(2).getEmail(), matches.get(2).getID(), "Bass" , "Jazz"));
                    session.setAttribute("prof4", new GhettoProfile(matches.get(3).getName(), matches.get(3).getEmail(), matches.get(3).getID(), "Guitar" , "Hip Hop"));
                    destPage = "dashboard.jsp";
                }

            } catch (SQLException | ClassNotFoundException ex) {
                throw new ServletException(ex);
            }
        }
     
        RequestDispatcher dispatch = request.getRequestDispatcher(destPage);
        dispatch.forward(request, response);
    }
}
