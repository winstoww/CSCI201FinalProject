import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import csci201finalprojx.GhettoProfile;
 
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
 
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String slatitude = request.getParameter("latitude");
        String slongitude = request.getParameter("longitude");
        String destPage = "survey.jsp"; //or .html?
        
        String pop = request.getParameter("range_pop");
        String rock = request.getParameter("range_rock");
        String jazz = request.getParameter("range_jazz");
        String country = request.getParameter("range_country");
        String folk = request.getParameter("range_folk");
        String blues = request.getParameter("range_blues");
        String hiphop = request.getParameter("range_hiphop");
        String othergenre = request.getParameter("range_other");
        
        String guit = request.getParameter("range_guitar");
        String bass = request.getParameter("range_bass");
        String drum = request.getParameter("range_drum");
        String piano = request.getParameter("range_piano");
        String viol = request.getParameter("range_violin");
        String trump = request.getParameter("range_trumpet");
        String sax = request.getParameter("range_saxophone");
        String otherinst = request.getParameter("range_other_instruments");
        
        
        ArrayList<Integer> instrumentRate = new ArrayList<Integer>();
        instrumentRate.add(Integer.parseInt(guit));
        instrumentRate.add(Integer.parseInt(bass));
        instrumentRate.add(Integer.parseInt(drum));
        instrumentRate.add(Integer.parseInt(piano));
        instrumentRate.add(Integer.parseInt(viol));
        instrumentRate.add(Integer.parseInt(trump));
        instrumentRate.add(Integer.parseInt(sax));
        instrumentRate.add(Integer.parseInt(otherinst));
        
        ArrayList<Integer> genreRate = new ArrayList<Integer>();
        genreRate.add(Integer.parseInt(pop));
        genreRate.add(Integer.parseInt(rock));
        genreRate.add(Integer.parseInt(jazz));
        genreRate.add(Integer.parseInt(country));
        genreRate.add(Integer.parseInt(folk));
        genreRate.add(Integer.parseInt(blues));
        genreRate.add(Integer.parseInt(hiphop));
        genreRate.add(Integer.parseInt(othergenre));
        
        System.out.println(instrumentRate);
        System.out.println(genreRate);
        System.out.println(name +" "+ email +" "+ password +" "+slatitude+" "+slongitude );
        
        ArrayList<String> instruments  = new ArrayList<String>();
        instruments.add("guitar");
        instruments.add("bass");
        instruments.add("drum");
        instruments.add("piano");
        instruments.add("violin");
        instruments.add("trumpet");
        instruments.add("saxaphone");
        instruments.add("other");
        
        Random rand = new Random();
        int rand_int1 = rand.nextInt(1000); 
        
        if (email == null || name == null || password == null || slatitude == null || slongitude == null || email.length() == 0 || 
        		password.length() == 0 || slatitude.length() == 0 || name.length() == 0 || slongitude.length() == 0) {
            request.setAttribute("register_message", "Fill in all boxes and select location on map");
            destPage = "survey.jsp";
        }
        else if (!email.contains("@")) {
            request.setAttribute("register_message", "Email is missing @");
            destPage = "survey.jsp";
        }
        else if (!email.contains(".")) {
            request.setAttribute("register_message", "Email is missing .com, .net, .edu, etc.");
            destPage = "survey.jsp";
        }
        else {
	    
        	try{
	            double latitude = Double.parseDouble(slatitude);
	            double longitude = Double.parseDouble(slongitude);
	            Location loc = new Location(latitude, longitude);  
	            Profile user = DBUserLogin.tryLogin(email, password);
			    if (user != null) {
			    	request.setAttribute("register_message", "Account already exists");
			    }
			    else { 
					Profile new_user =  new Profile(rand_int1, name, password, email, loc, instruments , genreRate, instrumentRate, true);
					Database data = new Database();
					data.createProfile(new_user);
					ArrayList<Profile> matches = new_user.matchmake(data.getAllProfiles()); 
					//ArrayList<Profile> matches = data.getAllProfiles();
					HttpSession session = request.getSession(); //HttpSession is used to store the user's information until logged out
					session.setAttribute("user", new GhettoProfile(user.getName(), user.getEmail(), user.getID(), "Bass", "Rock"));
					session.setAttribute("prof1", new GhettoProfile(matches.get(0).getName(), matches.get(0).getEmail(), matches.get(0).getID(), "Violin" , "Rock"));
                    session.setAttribute("prof2", new GhettoProfile(matches.get(1).getName(), matches.get(1).getEmail(), matches.get(1).getID(), "Saxophone" , "Blues"));
                    session.setAttribute("prof3", new GhettoProfile(matches.get(2).getName(), matches.get(2).getEmail(), matches.get(2).getID(), "Bass" , "Jazz"));
                    session.setAttribute("prof4", new GhettoProfile(matches.get(3).getName(), matches.get(3).getEmail(), matches.get(3).getID(), "Guitar" , "Hip Hop"));
					//session.setAttribute("connection", connection);
					destPage = "dashboard.jsp";
			    }
        	}
        	catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
          
        }
        
        RequestDispatcher dispatch = request.getRequestDispatcher(destPage);
        dispatch.forward(request, response);
    }
}
