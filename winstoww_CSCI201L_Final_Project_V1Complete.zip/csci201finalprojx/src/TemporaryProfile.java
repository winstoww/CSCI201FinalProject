import java.util.ArrayList;

public class TemporaryProfile extends Profile{

	public TemporaryProfile(int ProfileId,String name, String password, String email, Location Location,
			ArrayList<String> instruments, ArrayList<Integer> genres, ArrayList<Integer> skill, boolean isPermanent) {
		super(ProfileId,name, password, email, Location, instruments, genres, skill, isPermanent);
		// TODO Auto-generated constructor stub
	}

}
