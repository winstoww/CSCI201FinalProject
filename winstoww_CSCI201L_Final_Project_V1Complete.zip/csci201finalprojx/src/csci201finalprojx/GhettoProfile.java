package csci201finalprojx;

public class GhettoProfile {
	public String name;
	public String email;
	public int profileID;
	public String instrument;
	public String genre;
	
	public GhettoProfile(String name, String email, int profileId, String instrument, String genre ){
		this.email = email;
		this.name = name;
		this.profileID = profileId;
		this.instrument = instrument;
		this.genre = genre;
	}
	
	
	
	
}
