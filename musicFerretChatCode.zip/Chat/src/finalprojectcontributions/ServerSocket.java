import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import com.google.gson.Gson;

@ServerEndpoint(value = "/ws")

public class ServerSocket {

	@OnOpen
	public void open(Session session) {
		System.out.println("Connection Made!");
		//eventually gonna have to edit the section below
		String UserID = session.getQueryString().substring(session.getQueryString().indexOf('=')+1);
		System.out.println("ADDING: " + UserID);
		SocketMaps.addUser(UserID, session);
	}
	
	@OnMessage
	public void onMessage(String message, Session session) {
		Gson gson = new Gson();
		Message m = gson.fromJson(message, Message.class);
		System.out.println();
		System.out.println("In onMessage now");
		System.out.println("Username: "+ m.sender);
		System.out.println("Recipient: "+ m.recipient);
		System.out.println("Message: " + m.text);
		
		SocketMaps.deliver(message);
		
	}
	
	@OnClose
	public void close(Session session) {
		SocketMaps.removeUser("UserID");
		System.out.println("Disconnecting!");
		
	}

	@OnError
	public void error(Throwable error) {
		System.out.println("ERROR");
	}
}
