import java.io.IOException;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;

import javax.websocket.Session;

import com.google.gson.Gson;

public class SocketMaps {
	//two socket maps - one for active users, one for dormant users. Active users can send to dormant user, but it just gets stored temporarily until the next time they sign on 
	//use concurrent hashmaps to store both.
	//optional guest map? 
	private static ConcurrentHashMap<String, Session> activeMap= new ConcurrentHashMap<String, Session>();
	private static ConcurrentHashMap<String, Vector<Message>> dormantMap= new ConcurrentHashMap<String, Vector<Message>>();
	private static Gson gson = new Gson();
	
	public static boolean deliver(String m) {
		//parse JSON message, get message and recipient
		//see if the recipient is active, if yes, send to them, if no put in their dormant Vector
		Message message = gson.fromJson(m, Message.class);
		System.out.println();
		System.out.println("In Deliver now");
		System.out.println("sender: "+ message.sender);
		System.out.println("recipient: "+ message.recipient);
		System.out.println("text: "+ message.text);
		
		if(activeMap.containsKey(message.recipient)) {
			System.out.println("we're in");
			if(activeMap.get(message.recipient) != null) {
				System.out.println("it works");
				activeMap.get(message.recipient).getAsyncRemote().sendText(m);
			}
		}
		return false;
	}
	
	public static void checkInbox(String UserID) {
		//check their dormant vector and send messages to them over their socket in activeMap
		if (UserID==null || UserID.isEmpty()) {
			return ;
		}
		if (dormantMap.contains(UserID)) {
			Session s = activeMap.get(UserID);
			Vector<Message> v = dormantMap.get(UserID);
			if(v.size()>0) {
				for(Message m : v) {
					try {
						s.getBasicRemote().sendText(m.text);
					}catch(IOException ioe) {
						ioe.getMessage();
					}
				}
			}
		}
	}
	
	public static void addUser(String UserID, Session s) {
		//add a user & session to the active Map, if they don't already have a element in the dormant map, then they should b added to that as well
		if (UserID==null || s==null || UserID.isEmpty()) {
			return;
		}
		activeMap.put(UserID, s);
		if(!dormantMap.contains(UserID)) {
			dormantMap.put(UserID, new Vector<Message>());
		}
	}
	
	public static void removeUser(String UserID) {
		if(activeMap.contains(UserID)) {
			activeMap.remove(UserID);
		}
		
	}
	
}
